
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Medal, AlertCircle } from 'lucide-react';
import pb from '@/lib/pocketbaseClient.js';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils.js';

export default function ClassifichePage() {
  const [tournaments, setTournaments] = useState([]);
  const [selectedTournamentId, setSelectedTournamentId] = useState('');
  const [leaderboard, setLeaderboard] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const { currentUser } = useAuth();

  // Fetch tournaments for the dropdown
  useEffect(() => {
    const fetchTournaments = async () => {
      try {
        const records = await pb.collection('tornei').getFullList({
          sort: '-created',
          $autoCancel: false
        });
        setTournaments(records);
        if (records.length > 0) {
          setSelectedTournamentId(records[0].id);
        }
      } catch (error) {
        console.error("Error fetching tournaments:", error);
      }
    };
    fetchTournaments();
  }, []);

  // Fetch leaderboard data
  const fetchLeaderboard = async tournamentId => {
    if (!tournamentId) return;
    try {
      setIsLoading(true);
      const records = await pb.collection('classifiche').getList(1, 100, {
        filter: `torneo_id="${tournamentId}"`,
        sort: '-punti',
        $autoCancel: false
      });
      setLeaderboard(records.items);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLeaderboard(selectedTournamentId);

    // Polling every 10 seconds
    const interval = setInterval(() => {
      fetchLeaderboard(selectedTournamentId);
    }, 10000);
    return () => clearInterval(interval);
  }, [selectedTournamentId]);

  const getPositionIcon = index => {
    if (index === 0) return <Medal className="h-6 w-6 text-yellow-400" />;
    if (index === 1) return <Medal className="h-6 w-6 text-gray-400" />;
    if (index === 2) return <Medal className="h-6 w-6 text-amber-600" />;
    return <span className="font-bebas text-xl text-primary w-6 text-center inline-block">{index + 1}</span>;
  };

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-6">
          <div>
            <h1 className="font-bebas text-5xl tracking-wide mb-2">Classifiche <span className="text-primary">Live</span></h1>
            <p className="text-muted-foreground">I punteggi in tempo reale.</p>
          </div>
          
          <div className="w-full md:w-auto">
            <Select value={selectedTournamentId} onValueChange={setSelectedTournamentId}>
              <SelectTrigger className="w-full md:w-[250px] bg-card border-white/10 focus:ring-primary">
                <SelectValue placeholder="Seleziona Torneo" />
              </SelectTrigger>
              <SelectContent>
                {tournaments.map(t => <SelectItem key={t.id} value={t.id}>{t.nome}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Card className="bg-card border-white/10 overflow-hidden">
          <CardContent className="p-0">
            {isLoading && leaderboard.length === 0 ? (
              <div className="p-6 space-y-4">
                {[1, 2, 3, 4, 5].map(i => <Skeleton key={i} className="h-16 w-full bg-white/5" />)}
              </div>
            ) : leaderboard.length === 0 ? (
              <div className="text-center py-24">
                <AlertCircle className="h-12 w-12 text-primary mx-auto mb-4 opacity-50" />
                <h3 className="font-bebas text-2xl mb-2">Nessun dato disponibile</h3>
                <p className="text-muted-foreground">La classifica per questo torneo non è ancora stata generata.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-background/50">
                    <TableRow className="border-white/10 hover:bg-transparent">
                      <TableHead className="w-[100px] text-center text-primary">Posizione</TableHead>
                      <TableHead className="text-primary">Squadra</TableHead>
                      <TableHead className="text-right text-primary">Punti</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {leaderboard.map((row, index) => {
                      const isCurrentUser = currentUser && row.user_id === currentUser.id;
                      return (
                        <TableRow 
                          key={row.id} 
                          className={cn(
                            "border-white/5 transition-colors", 
                            isCurrentUser ? "bg-primary/10 hover:bg-primary/20" : "hover:bg-white/5"
                          )}
                        >
                          <TableCell className="text-center font-medium">
                            <div className="flex justify-center items-center">
                              {getPositionIcon(index)}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className={cn("font-medium", isCurrentUser ? "text-primary" : "text-foreground")}>
                              {row.squadra}
                            </div>
                            {isCurrentUser && <div className="text-xs text-primary mt-1 font-bold">La tua squadra</div>}
                          </TableCell>
                          <TableCell className="text-right font-bebas text-2xl text-secondary">
                            {row.punti}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
