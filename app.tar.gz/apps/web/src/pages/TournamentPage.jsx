
import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Users, CreditCard } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';

export default function TournamentPage() {
  const navigate = useNavigate();

  const handleEnrollClick = () => {
    navigate('/tournament/daily-cup');
  };

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-6">
          <div>
            <h1 className="font-bebas text-5xl tracking-wide mb-2">Tornei <span className="text-primary">Disponibili</span></h1>
            <p className="text-muted-foreground">Scegli il torneo adatto a te e inizia a giocare.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Card className="bg-card border-white/10 hover:border-primary/50 transition-colors duration-300 flex flex-col h-full">
              <CardHeader className="pb-4 border-b border-white/5">
                <CardTitle className="font-bebas text-3xl flex justify-between items-center group-hover:text-primary transition-colors">
                  Daily Cup
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6 flex-1 space-y-6">
                
                {/* Promotional Banner */}
                <div className="promo-banner w-full">
                  <img 
                    src="https://horizons-cdn.hostinger.com/0000523f-1fb8-4ea0-beed-e540c65722fa/5bc2adf990a9453f2bd425ae50914208.png" 
                    alt="Promozione Daily Cup con in palio un buono Amazon" 
                  />
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 bg-background/50 rounded-lg border border-white/5">
                    <div className="flex items-center gap-3 text-muted-foreground">
                      <Trophy className="h-5 w-5 text-secondary" />
                      <span className="font-medium">Montepremi</span>
                    </div>
                    <span className="font-bebas text-3xl text-secondary">100€</span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-background/30 rounded-lg border border-white/5">
                    <div className="flex items-center gap-3 text-muted-foreground">
                      <CreditCard className="h-4 w-4 text-primary" />
                      <span className="text-sm">Quota Iscrizione</span>
                    </div>
                    <span className="font-medium text-foreground">5€</span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-background/30 rounded-lg border border-white/5">
                    <div className="flex items-center gap-3 text-muted-foreground">
                      <Users className="h-4 w-4 text-primary" />
                      <span className="text-sm">Posti Disponibili</span>
                    </div>
                    <span className="font-medium text-foreground">Max 100</span>
                  </div>
                </div>

                <p className="text-muted-foreground text-sm leading-relaxed">
                  Il torneo giornaliero perfetto per mettere alla prova le tue abilità manageriali.
                </p>
              </CardContent>
              <CardFooter className="pt-4 border-t border-white/5">
                <Button 
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 text-lg h-12 transition-all active:scale-[0.98]"
                  onClick={handleEnrollClick}
                >
                  Scopri di più
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
