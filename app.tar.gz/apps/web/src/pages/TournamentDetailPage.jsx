
import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Trophy, Users, Clock, BookOpen, Gift, ShieldCheck, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useCart } from '@/hooks/useCart.jsx';
import { useToast } from '@/hooks/use-toast';

export default function TournamentDetailPage() {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { toast } = useToast();

  const handleAddToCart = () => {
    const product = {
      id: 'daily-cup',
      title: 'Daily Cup',
      name: 'Daily Cup',
      image: 'https://images.unsplash.com/photo-1702254920341-3aea47e061df'
    };
    
    const variant = {
      id: 'daily-cup-entry',
      title: 'Iscrizione Torneo',
      price_in_cents: 10000,
      currency_info: {
        symbol: '€',
        code: 'EUR'
      },
      manage_inventory: false
    };

    addToCart(product, variant, 1, 999);
    
    toast({
      title: "Aggiunto al carrello",
      description: "L'iscrizione alla Daily Cup è stata aggiunta al tuo carrello.",
    });
  };

  const details = [
    { icon: <Trophy className="h-5 w-5 text-primary" />, label: "Tipo di torneo", value: "Daily Cup" },
    { icon: <Users className="h-5 w-5 text-primary" />, label: "Partecipanti", value: "Max 100" },
    { icon: <Clock className="h-5 w-5 text-primary" />, label: "Durata", value: "1 giornata di campionato" },
    { icon: <BookOpen className="h-5 w-5 text-primary" />, label: "Regole", value: "Standard Fantasy Rules" },
    { icon: <Gift className="h-5 w-5 text-primary" />, label: "Premi", value: "Top 3 classificati" },
    { icon: <ShieldCheck className="h-5 w-5 text-primary" />, label: "Requisiti", value: "18+, Metodo di pagamento valido" },
  ];

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Hero Section */}
      <div className="relative h-[40vh] md:h-[50vh] w-full overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://horizons-cdn.hostinger.com/0000523f-1fb8-4ea0-beed-e540c65722fa/chatgpt-image-26-gen-2026-03_22_32-UshJf.png" 
            alt="Daily Cup Tournament" 
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-end pb-12">
          <Button 
            variant="ghost" 
            className="w-fit mb-6 text-muted-foreground hover:text-primary hover:bg-white/5 -ml-4"
            onClick={() => navigate('/tornei')}
          >
            <ArrowLeft className="mr-2 h-4 w-4" /> Torna ai Tornei
          </Button>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="font-bebas text-6xl md:text-8xl tracking-wide text-foreground mb-4">
              Daily <span className="text-primary">Cup</span>
            </h1>
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-xl bg-secondary/10 border border-secondary/20 backdrop-blur-md">
              <span className="text-lg font-medium text-muted-foreground uppercase tracking-wider">Montepremi dal valore di</span>
              <span className="font-bebas text-4xl text-secondary">100€</span>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Content Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        
        {/* Top Side-by-Side Section: Banner & Action Card */}
        <div className="flex flex-col lg:flex-row gap-8 mb-16 items-center lg:items-start justify-between">
          
          {/* Promotional Banner (Left) */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.05 }}
            className="w-full lg:flex-1 flex justify-center lg:justify-start"
          >
            <div className="promo-banner">
              <img 
                src="https://horizons-cdn.hostinger.com/0000523f-1fb8-4ea0-beed-e540c65722fa/5bc2adf990a9453f2bd425ae50914208.png" 
                alt="Promozione Daily Cup con in palio un buono Amazon" 
              />
            </div>
          </motion.div>

          {/* Action Card (Right) */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="w-full lg:w-[400px] shrink-0"
          >
            <Card className="bg-card border-primary/20 shadow-2xl shadow-primary/5">
              <CardContent className="p-6 space-y-6">
                <div className="text-center pb-6 border-b border-white/10">
                  <p className="text-sm text-muted-foreground uppercase tracking-wider mb-2">Quota di Iscrizione</p>
                  <p className="font-bebas text-5xl text-foreground">5€</p>
                </div>
                
                <ul className="space-y-3 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <ShieldCheck className="h-4 w-4 text-primary" /> Pagamento sicuro
                  </li>
                  <li className="flex items-center gap-2">
                    <Trophy className="h-4 w-4 text-primary" /> Montepremi garantito
                  </li>
                </ul>

                <Button 
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 text-lg h-14 shadow-lg shadow-primary/20 transition-all active:scale-[0.98]"
                  onClick={handleAddToCart}
                >
                  <ShoppingCart className="mr-2 h-5 w-5" /> Aggiungi al Carrello
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Bottom Section: Details & Description */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 space-y-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h2 className="font-bebas text-3xl mb-6 text-foreground">Caratteristiche del Torneo</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {details.map((detail, index) => (
                  <Card key={index} className="bg-card/50 border-white/5 hover:border-primary/30 transition-colors">
                    <CardContent className="p-4 flex items-start gap-4">
                      <div className="p-2 rounded-lg bg-white/5">
                        {detail.icon}
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">{detail.label}</p>
                        <p className="font-medium text-foreground">{detail.value}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="prose prose-invert max-w-none"
            >
              <h3 className="font-bebas text-2xl text-foreground mb-4">Descrizione</h3>
              <p className="text-muted-foreground leading-relaxed">
                La Daily Cup è il torneo perfetto per chi vuole un'esperienza rapida e competitiva. 
                Componi la tua squadra ideale con un budget limitato e sfida altri 99 fanta-allenatori. 
                I punteggi vengono calcolati in base alle prestazioni reali dei giocatori nelle partite della giornata.
                Solo i migliori 3 classificati si divideranno il montepremi garantito.
              </p>
            </motion.div>
          </div>
        </div>

      </div>
    </div>
  );
}
